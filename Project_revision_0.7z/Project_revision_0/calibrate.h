/*
 * calibrate.h
 *
 *  Created on: Mar 6, 2020
 *      Author: dylan1
 */

#ifndef CALIBRATE_H_
#define CALIBRATE_H_
#include "open_interface.h"

double autoCalib(oi_t *sensor_data);




#endif /* CALIBRATE_H_ */
